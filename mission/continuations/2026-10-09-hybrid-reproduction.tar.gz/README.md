This packet reproduces a read-only audit of public `reppiks490/Icarus-engine` Git data at the explicitly pinned commit `0f1089f9fd6e412e11fd8c69afef508099638869`. Its commit time is `2026-10-09T17:12:27Z`; the main SHA was observed at `2026-10-09T17:14:18.642Z`. The observation time is distinct from the commit time. These counts do not describe subsequent live main.

The pinned population contains 478 unique immutable requests, four byte-identical `latest.json` mirrors excluded from that denominator, and six stored result files. Five results are structurally valid `BLOCKED` dispositions. One `NO_MATERIAL_DELTA` result for `alpha_synthesis-20261004T192000Z` has a string `substantive_work_performed` and is invalid. Thus 473 requests remain unresolved: 472 have no matching result, and one has an invalid result. There is no stored `MATERIAL_DELTA` result.

| Lane | Immutable requests | Valid dispositions | Unresolved |
| --- | ---: | ---: | ---: |
| advanced_csv | 120 | 1 | 119 |
| alpha_synthesis | 119 | 0 | 119 |
| microstructure_sensor_grid | 119 | 4 | 115 |
| robustness_guardian | 120 | 0 | 120 |

| Public Git object | Exact SHA |
| --- | --- |
| Source commit | 0f1089f9fd6e412e11fd8c69afef508099638869 |
| Root tree | 244fd850b47a7f379549c4f8cc5a19ba01d231a7 |
| automation_intelligence tree | 048200db7cfc8b2840017055556f4a2c7e7d9a53 |
| hybrid_loop_fabric_v1 tree | f99b4d584b48b7d6c172a9813746aaf0ef25a605 |
| tools tree | 360ae83c8ac2e7e933a7adbe03a6665e5b97393c |
| tools/hybrid_loop_bridge.py blob | b66d46978d5fef6642cc332486b0ae01907b5afd |
| hybrid registry.json blob | ce3e6cd23abaf28f913d1b62178416699587fa4a |

Run the following from this packet's directory using Python (validated on Python 3.12) and a filesystem that supports symlinks. The script uses only the Python standard library and supplied local public inputs; it performs no fetching or network requests. The output directory must be new or empty, separate from the inputs, with an existing parent.

```sh
python reproduce.py \
  --input-dir ./inputs \
  --blob-dir ./blobs \
  --prior-report ./prior-report.json \
  --output-dir ./scratch-reproduction
```

The CLI explicitly accepts all input and output locations, so the packet can be moved to any directory. All runtime writes, including temporary shadow symlinks and byte-exact result copies, stay within the supplied scratch output directory. Inputs and source records are read only. The script does not call enqueue, canonical health writers, or any completion writer. `SHA256SUMS` authenticates the supplied packet files; every raw blob also receives independent Git-object SHA and tree-size checks during reproduction.

`inputs/` contains the source tree metadata, population manifest, pinned registry and shipped validator, unchanged strict audit source, and main observation metadata. `blobs/` contains exactly the 484 distinct raw public population blobs named by their Git SHA. `prior-report.json` preserves the earlier public-derived report pinned to `b9e6013aa578c1638ed5fb023563776ff72d5888`. `reconciliation.json` contains the portable reproduction result, and `stored-results/` contains exact raw copies of all six results. `SHA256SUMS` includes their hashes.

The audit rehashes the root/automation/tools/hybrid trees and all 15 nested hybrid trees, confirms the recursive metadata is not truncated, verifies all 488 population path entries, and executes the actual shipped `result_valid` function for all 478 immutable requests using their pinned current registry automation IDs. Every request identity and stored contract fingerprint matches that registry. Shipped validation checks timestamp keys but does not parse clocks; strict reconciliation separately validates aware timestamps, completion ordering, exact paths, original request metadata when recorded, schema and identity invariants. The accepted sets agree at this snapshot. All clocks checked are aware, and five historical requests that omit `due_slot_utc` explicitly use `requested_at_utc` for ordering.

Current shipped health computes total and oldest backlog over the complete immutable population; its 24-file recent window is a separate diagnostic. Health included in the report is a read-only calculation at the pinned commit time, not a newly stored canonical health snapshot or a historical worker completion.

All 372 prior immutable request blobs and all six prior result path/blob pairs remain unchanged. The 106 added immutable requests increase unresolved requests from 367 to 473. The packet includes only already-public Git data and derived verification metadata. Structural acceptance of a `BLOCKED` disposition does not establish worker cognition, source-domain correctness, or historical read-back. The original historical report and source snapshots were preserved.
