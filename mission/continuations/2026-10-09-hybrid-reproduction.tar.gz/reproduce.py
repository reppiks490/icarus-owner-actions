"""Reproduce the read-only, current-main pinned hybrid reconciliation."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import sys
import tempfile

sys.dont_write_bytecode = True


def digest(raw: bytes, kind: str = "blob") -> str:
    return hashlib.sha1(kind.encode() + b" " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def tree_hash(rows: list[dict]) -> str:
    rows = sorted(rows, key=lambda e: (e["path"] + ("/" if e["type"] == "tree" else "")).encode())
    raw = b"".join(
        (e["mode"].lstrip("0") + " " + e["path"]).encode() + b"\0" + bytes.fromhex(e["sha"])
        for e in rows
    )
    return digest(raw, "tree")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-dir", type=Path, required=True, help="Directory containing the supplied pinned metadata, registry, validator, and audit inputs")
    parser.add_argument("--blob-dir", type=Path, required=True, help="Directory of public raw population blobs named <git-blob-sha>.json")
    parser.add_argument("--prior-report", type=Path, required=True, help="Prior pinned public reconciliation JSON for historical byte comparison")
    parser.add_argument("--output-dir", type=Path, required=True, help="New or empty scratch directory; all generated files are written here")
    args = parser.parse_args()
    HERE = args.input_dir.resolve()
    CACHE = args.blob_dir.resolve()
    prior_report = args.prior_report.resolve()
    output_dir = args.output_dir.resolve()
    if not HERE.is_dir() or not CACHE.is_dir() or not prior_report.is_file():
        parser.error("Input directory, blob directory, and prior report must exist")
    if output_dir == HERE or output_dir.is_relative_to(HERE) or output_dir == CACHE or output_dir.is_relative_to(CACHE):
        parser.error("Output directory must be separate from the read-only input directories")
    if output_dir == prior_report or output_dir.is_relative_to(prior_report):
        parser.error("Output directory must be separate from the prior report")
    if not output_dir.parent.is_dir():
        parser.error("The scratch output directory's parent must already exist")
    if output_dir.exists() and (not output_dir.is_dir() or any(output_dir.iterdir())):
        parser.error("Output directory must be new or empty")
    output_dir.mkdir(exist_ok=True)
    pin = json.loads((HERE / "main-pin.json").read_text())
    metadata = {name: json.loads((HERE / (name + "-tree.json")).read_text()) for name in ["root", "automation", "tools", "hybrid"]}
    for name, tree in metadata.items():
        assert tree.get("truncated") is False, name
        roots = [e for e in tree["tree"] if "/" not in e["path"]]
        assert tree_hash(roots) == tree["sha"], (name, "tree SHA mismatch")
    assert pin["tree_sha"] == metadata["root"]["sha"]
    assert next(e for e in metadata["root"]["tree"] if e["path"] == "automation_intelligence")["sha"] == metadata["automation"]["sha"]
    assert next(e for e in metadata["root"]["tree"] if e["path"] == "tools")["sha"] == metadata["tools"]["sha"]
    assert next(e for e in metadata["automation"]["tree"] if e["path"] == "hybrid_loop_fabric_v1")["sha"] == metadata["hybrid"]["sha"]
    nested_verified = 0
    for directory in metadata["hybrid"]["tree"]:
        if directory["type"] != "tree":
            continue
        prefix = directory["path"] + "/"
        rows = [{**e, "path": e["path"][len(prefix):]} for e in metadata["hybrid"]["tree"] if e["path"].startswith(prefix) and "/" not in e["path"][len(prefix):]]
        assert tree_hash(rows) == directory["sha"], directory["path"]
        nested_verified += 1

    audit_path = HERE / "audit_hybrid_reconciliation.py"
    audit = load_module("current_hybrid_strict_audit", audit_path)
    validator_path = HERE / "current-hybrid_loop_bridge.py"
    validator_meta = next(e for e in metadata["tools"]["tree"] if e["path"] == "hybrid_loop_bridge.py")
    validator_bytes = validator_path.read_bytes()
    assert len(validator_bytes) == validator_meta["size"] and digest(validator_bytes) == validator_meta["sha"]
    bridge = load_module("current_shipped_hybrid_bridge", validator_path)
    registry_meta = next(e for e in metadata["hybrid"]["tree"] if e["path"] == "registry.json")
    registry_bytes = (HERE / "registry.json").read_bytes()
    assert len(registry_bytes) == registry_meta["size"] and digest(registry_bytes) == registry_meta["sha"]
    manifest_path = HERE / "population-tree.json"
    manifest = json.loads(manifest_path.read_text())
    assert manifest["sha"] == pin["sha"]
    prefix = "automation_intelligence/hybrid_loop_fabric_v1/"
    for kind, directory in [("req", "requests/"), ("res", "results/")]:
        expected = [{**e, "path": prefix + e["path"]} for e in metadata["hybrid"]["tree"] if e["type"] == "blob" and e["path"].startswith(directory) and e["path"].endswith(".json")]
        assert manifest[kind] == expected, kind
    report = audit.reconcile(manifest_path, CACHE)
    payloads = {e["path"]: json.loads((CACHE / (e["sha"] + ".json")).read_bytes()) for e in manifest["req"] + manifest["res"]}
    current_identity_errors = []
    shipped_valid = set()
    shipped_unresolved = {}
    computed_health = {}
    validation_calls = []
    strict_valid = {r["request_id"] for r in report["immutable_requests_oldest_first"] if r["strict_valid_matching_result"]}
    clock_instant = audit.clock(pin["commit_date"])
    with tempfile.TemporaryDirectory(prefix="icarus-current-hybrid-readonly-", dir=output_dir) as tmp:
        shadow = Path(tmp)
        for e in manifest["req"] + manifest["res"]:
            target = shadow / e["path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.symlink_to(CACHE / (e["sha"] + ".json"))
        registry_target = shadow / bridge.REGISTRY
        registry_target.parent.mkdir(parents=True, exist_ok=True)
        registry_target.symlink_to(HERE / "registry.json")
        registry = bridge.load_registry(shadow)
        for e in manifest["req"]:
            if PurePosixPath(e["path"]).name == "latest.json":
                continue
            payload = payloads[e["path"]]
            lane = payload["lane"]
            current_id = registry["lanes"][lane]["automation_id"]
            failures = []
            if payload["automation_id"] != current_id:
                failures.append("CURRENT_REGISTRY_AUTOMATION_ID_MISMATCH")
            if payload["contract_registry_path"] != str(bridge.REGISTRY):
                failures.append("CONTRACT_REGISTRY_PATH_MISMATCH")
            failures += [i["code"] for i in report["issues"] if i["path"] == e["path"]]
            if failures:
                current_identity_errors.append({"path": e["path"], "codes": failures})
                strict_valid.discard(payload["request_id"])
            accepted = bridge.result_valid(shadow, lane, current_id, payload["request_id"])
            if accepted:
                shipped_valid.add(payload["request_id"])
            validation_calls.append({"request_id": payload["request_id"], "lane": lane, "registry_automation_id": current_id, "shipped_result_valid": accepted, "strict_valid_matching_result": payload["request_id"] in strict_valid})
        for lane, cfg in registry["lanes"].items():
            shipped_unresolved[lane] = bridge.unresolved_requests(shadow, lane, str(cfg["automation_id"]), limit=0)
            computed_health[lane] = bridge.build_health(shadow, lane, cfg, clock_instant)
    audit_valid = {r["request_id"] for r in report["immutable_requests_oldest_first"] if r["strict_valid_matching_result"]}
    assert strict_valid == audit_valid, "Request/current-identity errors require separate strict reconciliation"
    assert not current_identity_errors
    assert sorted(r for ids in shipped_unresolved.values() for r in ids) == sorted(r["request_id"] for r in validation_calls if not r["shipped_result_valid"])
    for lane, info in report["lanes"].items():
        info["current_registry_automation_id"] = registry["lanes"][lane]["automation_id"]
        info["current_registry_state"] = bridge.lane_state(registry["lanes"][lane])
        info["current_registry_contract_fingerprint"] = bridge.canonical_sha256(registry["lanes"][lane])
        info["stored_request_fingerprints_equal_current_registry"] = info["contract_fingerprints"] == [info["current_registry_contract_fingerprint"]]
        info["shipped_unresolved_count_full_population"] = len(shipped_unresolved[lane])
        info["shipped_oldest_unresolved_request_id"] = shipped_unresolved[lane][0] if shipped_unresolved[lane] else None
        strict_lane = [r["request_id"] for r in report["immutable_requests_oldest_first"] if r["lane"] == lane and not r["strict_valid_matching_result"]]
        assert shipped_unresolved[lane] == strict_lane

    report["schema_version"] = "icarus-current-main-pinned-hybrid-reconciliation-v2"
    report["observed_at_utc"] = pin["observed_at_utc"]
    report["source_tree_sha"] = pin["tree_sha"]
    report["source_hybrid_tree_sha"] = metadata["hybrid"]["sha"]
    report["source_commit_date_utc"] = pin["commit_date"]
    report["main_sha_observed_at_utc"] = pin["observed_at_utc"]
    report["snapshot_claim"] = "All counts are pinned to source_commit_sha; no claim about subsequent live main."
    report["integrity"].update({"root_and_automation_and_tools_and_hybrid_tree_sha_verified": True, "nested_hybrid_tree_objects_rehashed": nested_verified, "recursive_hybrid_tree_truncated": False})
    report["audit_source_sha256"] = hashlib.sha256(audit_path.read_bytes()).hexdigest()
    report["reproduction_source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report["registry_check"] = {"git_blob_sha": registry_meta["sha"], "sha256": hashlib.sha256(registry_bytes).hexdigest(), "size_bytes": len(registry_bytes), "registered_lanes": len(registry["lanes"]), "request_population_lanes": len(report["lanes"]), "request_registry_identity_and_path_errors": current_identity_errors, "all_immutable_requests_match_pinned_current_registry_identity": True}
    report["pinned_validator_check"] = {"repository_path": "tools/hybrid_loop_bridge.py", "source_commit_sha": pin["sha"], "git_blob_sha": validator_meta["sha"], "sha256": hashlib.sha256(validator_bytes).hexdigest(), "source_size_bytes": len(validator_bytes), "result_valid_executed_for_all_immutable_requests": len(validation_calls), "identity_argument_source": "Pinned registry lane automation_id", "validator_valid_matching_results": len(shipped_valid), "validator_unresolved": len(validation_calls) - len(shipped_valid), "shipped_valid_request_ids": sorted(shipped_valid), "shipped_only_valid_request_ids": sorted(shipped_valid - strict_valid), "strict_only_valid_request_ids": sorted(strict_valid - shipped_valid), "audit_and_pinned_validator_agree_at_this_snapshot": shipped_valid == strict_valid, "shipped_validator_scope": "Required keys, exact identity/schema, outcome, boolean and list types, execution_authorized false. Result clocks are present but not parsed by result_valid.", "strict_audit_additional_scope": "Aware request/result clocks, completion ordering, original request metadata if recorded, exact immutable path and required result path, duplicate and orphan identities, and pinned current registry request identity."}
    report["validation_calls"] = validation_calls
    report["computed_shipped_health_at_commit_time"] = computed_health
    report["computed_health_note"] = "Read-only build_health calls in an isolated symlink shadow, using source_commit_date_utc for observed_at_utc; these are calculations, not new stored canonical health or historical worker completions."
    report["raw_stored_results"] = []
    result_dir = output_dir / "stored-results"
    result_dir.mkdir(exist_ok=True)
    for e in manifest["res"]:
        raw = (CACHE / (e["sha"] + ".json")).read_bytes()
        (result_dir / (e["sha"] + ".json")).write_bytes(raw)
        p = payloads[e["path"]]
        current_id = registry["lanes"][p["lane"]]["automation_id"]
        report["raw_stored_results"].append({"repository_path": e["path"], "git_blob_sha": e["sha"], "size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "exact_raw_byte_copy": "stored-results/" + e["sha"] + ".json", "payload": p, "current_registry_identity_matches": p["automation_id"] == current_id, "all_present_clock_fields_are_aware": all(audit.clock(p[k]) is not None for k in ["started_at_utc", "completed_at_utc", "original_due_slot_utc", "original_requested_at_utc"] if k in p), "completed_at_or_after_started_at": audit.clock(p["completed_at_utc"]) >= audit.clock(p["started_at_utc"])})

    old_path = prior_report
    old = json.loads(old_path.read_text())
    old_requests = {r["request_id"]: r["request_blob_sha"] for r in old["immutable_requests_oldest_first"]}
    new_requests = {r["request_id"]: r["request_blob_sha"] for r in report["immutable_requests_oldest_first"]}
    old_results = {r["result_path"]: r["result_blob_sha"] for r in old["results"]}
    new_results = {r["result_path"]: r["result_blob_sha"] for r in report["results"]}
    report["prior_snapshot_comparison"] = {"prior_source_commit_sha": old["source_commit_sha"], "prior_report_sha256": hashlib.sha256(old_path.read_bytes()).hexdigest(), "old_counts": old["counts"], "added_immutable_request_ids": sorted(new_requests.keys() - old_requests.keys()), "removed_immutable_request_ids": sorted(old_requests.keys() - new_requests.keys()), "changed_prior_request_blob_ids": sorted(k for k in old_requests.keys() & new_requests.keys() if old_requests[k] != new_requests[k]), "prior_result_path_blob_mapping_unchanged": old_results == new_results, "immutable_request_count_delta": len(new_requests) - len(old_requests), "strict_unresolved_count_delta": report["counts"]["strict_unresolved_immutable_requests"] - old["counts"]["strict_unresolved_immutable_requests"]}
    assert not report["prior_snapshot_comparison"]["removed_immutable_request_ids"]
    assert not report["prior_snapshot_comparison"]["changed_prior_request_blob_ids"]
    assert report["prior_snapshot_comparison"]["prior_result_path_blob_mapping_unchanged"]
    report["limitations"] = ["These counts describe the explicitly pinned Git snapshot and are not live counts.", "Shipped validator acceptance and stricter aware-clock reconciliation are shown separately; at this snapshot they accept the same five BLOCKED dispositions.", "One stored NO_MATERIAL_DELTA result has a string substantive_work_performed and remains invalid; its raw bytes and type are preserved.", "Valid stored dispositions do not prove worker cognition, source-domain correctness, or historical read-back.", f"{len(report['latest_mirrors'])} mutable latest.json aliases are byte-identical to immutable targets and excluded from the denominator.", f"{len(report['due_slot_fallback_request_ids'])} old requests omit due_slot_utc and are ordered by their aware requested_at_utc; present invalid due-slot fields never fall back.", "Current shipped health uses the complete immutable population for total/oldest backlog; the recent 24-file window is a separate diagnostic.", "No canonical record, schedule, workflow, result, index, or historical completion was written. Artifacts contain only already-public Git data and derived verification metadata."]
    (output_dir / "reconciliation.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"source_commit_sha": pin["sha"], "counts": report["counts"], "registry_identity_errors": current_identity_errors, "shipped_strict_agreement": shipped_valid == strict_valid, "historical_request_and_result_bytes_preserved": True}, indent=2))


if __name__ == "__main__":
    main()
